from django.conf import settings
from main.models import User
import requests
import logging

logger = logging.getLogger(__name__)


def handle_telegram_message(update):
    if 'message' not in update:
        return

    message = update['message']
    text = message.get('text', '')
    chat_id = message['chat']['id']

    # Команда /start
    if text.startswith('/start'):
        parts = text.split()
        code = parts[1] if len(parts) > 1 else None

        # Если код не указан
        if not code:
            send_message(chat_id, "🔑 Для привязки аккаунта используйте ссылку из вашего профиля в системе")
            return
            # Проверка на уже привязанный аккаунт
        try:
            userProv = User.objects.get(telegram_id=chat_id)
            send_message(chat_id, "⚠️ Этот аккаунт уже привязан к другому Telegram ID")
            return
        except User.DoesNotExist:
            #send_message(chat_id, "⚠️ Этот аккаунт уже привязан к другому Telegram ID")
            pass
        try:
            user = User.objects.get(telegram_bind_code=code)
            user.telegram_id = chat_id
            user.telegram_bind_code = None  # Делаем код одноразовым
            user.save()

            logger.info(f"Telegram account linked: user={user.id}, telegram_id={chat_id}")
            send_message(chat_id, "✅ Ваш аккаунт успешно привязан!\n"
                                  "Теперь вы будете получать уведомления в этом чате.")

        except User.DoesNotExist:
            logger.warning(f"Invalid bind code attempted: {code}")
            send_message(chat_id, "❌ Неверный код привязки. Пожалуйста, получите новый код в вашем профиле")
        except Exception as e:
            logger.error(f"Error binding Telegram account: {str(e)}")
            send_message(chat_id, "⚠️ Произошла ошибка при привязке аккаунта. Пожалуйста, попробуйте позже")


def format_notification(notification):
    emoji_map = {
        'application_status': '🔔',
        'interview': '🗓',
        'test_task_upload': '📝',
        'vacancy_closed': '⚠️'
    }
    return f"{emoji_map.get(notification.notification_type, '')} {notification.content}"


def send_message(chat_id, text):
    try:
        url = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "HTML"
        }
        response = requests.post(url, json=payload)
        response.raise_for_status()  # Проверка на ошибки HTTP
    except requests.exceptions.RequestException as e:
        logger.error(f"Telegram API error: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error sending Telegram message: {str(e)}")