from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import LoginView
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from django.views.generic import CreateView, UpdateView
from django.contrib.auth import get_user_model
from .forms import RegisterUserForm
from main.models import Employee, WorkShift, Salary, Interview
from datetime import datetime, timedelta
from django.views.generic import TemplateView
from django.contrib.auth.mixins import PermissionRequiredMixin, UserPassesTestMixin
from calendar import monthrange
from .forms import AnswerUploadForm, BookInterviewForm
from django.utils import timezone
from django.shortcuts import get_object_or_404
from django.contrib import messages
from django.shortcuts import redirect
from django.shortcuts import render
import json
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from services.telegram import handle_telegram_message
from django.http import JsonResponse
import random



class LoginUser (LoginView):
    form_class = AuthenticationForm
    template_name = 'users/login.html'
    extra_context = {'title' : 'Авторизация'}
    def get_success_url(self):
        return reverse_lazy('users:profile')

def logout_users(request):
    logout(request)
    return HttpResponseRedirect(reverse('users:login'))

class RegisterUser(CreateView):
    form_class = RegisterUserForm
    template_name = 'users/register.html'
    extra_context = {'title' : 'Регистрация'}
    success_url = reverse_lazy('users:login')

class ProfileUser(LoginRequiredMixin, UpdateView):
    model = get_user_model()
    template_name = 'users/profile.html'
    form_class = AnswerUploadForm
    extra_context = {'title': 'Профиль'}
    def get_success_url(self):
        return reverse_lazy('users:profile')
    def get_object(self, queryset=None):
        return self.request.user

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.groups.filter(name='candidate').exists():
            employee = self.request.user.employee
            # Активное собеседование текущего кандидата
            context['active_interview'] = Interview.objects.filter(
                employee=employee  # Используем существующее поле employee
            ).first()


            # Доступные слоты для вакансии кандидата
            if employee.vacancy:
                context['available_slots'] = Interview.objects.filter(
                    is_available=True,
                    datetime__gte=timezone.now(),
                    hr = employee.vacancy.hr,
                    #application__vacancy=employee.vacancy,
                    employee__isnull=True  # Слоты без привязанного сотрудника
                ).order_by('datetime')[:5]
            else:
                context['available_slots'] = []
        return context
    def form_valid(self, form):
        self.object = form.save()
        if 'answer_file' in self.request.FILES:
            #print(self.request.FILES)
            self.object.employee.answer_file = self.request.FILES['answer_file']
            #form.instance.answer_file = self.request.FILES['answer_file']

            self.object.employee.save()
            #messages.success(self.request, "Файл успешно загружен!")
        if 'resume' in self.request.FILES:
            #print(self.request.FILES)
            self.object.employee.resume = self.request.FILES['resume']
            #form.instance.answer_file = self.request.FILES['answer_file']

            self.object.employee.save()
            #messages.success(self.request, "Файл успешно загружен!")
        return super().form_valid(form)

class VacancyСandidate(TemplateView):
    model = get_user_model()
    template_name = 'users/vacancy.html'
    #form_class = RegisterUserForm
    extra_context = {'title': 'Вакансия'}
#график
class ShiftCalendarView(UserPassesTestMixin, TemplateView):
    model = get_user_model()
    template_name = 'users/shift_calendar.html'

    def test_func(self):
        user = self.request.user
        target_pk = self.kwargs.get('pk')

        if not user.is_authenticated:
            return False

        # Суперпользователь имеет полный доступ
        if user.is_superuser:
            return True

        # Проверка групп администратора и HR
        is_admin = user.groups.filter(name='admin').exists()
        is_hr = user.groups.filter(name='hr').exists()

        # Доступ если:
        # 1. Админ/HR ИЛИ
        # 2. Пользователь смотрит свой календарь
        return (is_admin or is_hr) or user.employee.pk == target_pk

    def get(self, request, *args, **kwargs):
        context = self.get_context_data(**kwargs)
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        shift_id = request.POST.get('shift_id')
        try:
            shift = WorkShift.objects.get(id=shift_id, employee_id=self.kwargs['pk'])
            shift.delete()
            messages.success(request, "Смена успешно удалена")
        except WorkShift.DoesNotExist:
            messages.error(request, "Смена не найдена")

        return redirect(self.request.path_info)


    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        target_pk = self.kwargs['pk']
        #target_employee = Employee.objects.get(pk=target_pk)

        # Для админа/HR показываем выбор сотрудника
        context['show_employee_switcher'] = (
                self.request.user.is_superuser or
                self.request.user.groups.filter(name__in=['admin', 'HR']).exists()
        )
        # Определяем месяц для отображения
        try:
            year = int(self.kwargs.get('year', datetime.now().year))
            month = int(self.kwargs.get('month', datetime.now().month))
        except ValueError:
            year = datetime.now().year
            month = datetime.now().month
        # Рассчитываем даты навигации
        prev_date = datetime(year, month, 1) - timedelta(days=1)
        next_date = datetime(year, month, 28) + timedelta(days=4)
        # Формируем данные календаря
        _, num_days = monthrange(year, month)
        weeks = []
        week = []

        for day in range(1, num_days + 1):
            current_date = datetime(year, month, day)
            if current_date.weekday() != 0 and day == 1:
                for i in range(1, current_date.weekday()+1):
                    week.append({
                        'date': '',
                        'shifts': ''
                    })
            week.append({
                'date': current_date,
                'shifts': WorkShift.objects.filter(date=current_date.date())
            })

            if current_date.weekday() == 6:  # Воскресенье
                weeks.append(week)
                week = []

        if week:  # Добавляем последнюю неделю
            weeks.append(week)

        context.update({

            'weeks': weeks,
            'current_month': datetime(year, month, 1),
            'prev_month': prev_date.month,
            'prev_year': prev_date.year,
            'next_month': next_date.month,
            'next_year': next_date.year,
            'next_date' : next_date,
            'prev_date': prev_date,
            'name' : Employee.objects.filter(pk = self.kwargs['pk'])


        })
        context['can_edit_shifts'] = (
                self.request.user.is_superuser or
                self.request.user.groups.filter(name__in=['hr', 'admin']).exists()
        )
        return context


class MySalaryView(LoginRequiredMixin, TemplateView):
    template_name = 'users/my_salary.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        employee = self.request.user.employee

        # Получаем выбранный год из GET-параметра
        selected_year = self.request.GET.get('year')

        # Базовый запрос
        salaries = Salary.objects.filter(employee=employee)

        # Фильтрация по году
        if selected_year and selected_year.isdigit():
            selected_year = int(selected_year)
            salaries = salaries.filter(year=selected_year)

        # Уникальные года для выпадающего списка
        context['years'] = Salary.objects.filter(employee=employee)\
        .values_list('year', flat=True)\
        .distinct()\
        .order_by('-year')

        # Все записи с сортировкой
        context['salaries'] = salaries.order_by('-year', '-month')
        context['selected_year'] = selected_year or "Все периоды"

        return context

@csrf_exempt
def telegram_webhook(request):
    if request.method == 'POST':
        try:
            update = json.loads(request.body.decode('utf-8'))
            handle_telegram_message(update)
            return HttpResponse(status=200)
        except Exception as e:
            print(f"Error: {e}")
            return HttpResponse(status=500)
    return HttpResponse(status=403)



def generate_bind_code(request):
    if request.user.is_authenticated:
        code = str(random.randint(100000, 999999))
        request.user.telegram_bind_code = code
        request.user.save()
        return JsonResponse({'code': code})
    return JsonResponse({'error': 'Unauthorized'}, status=401)


class BookInterviewView(LoginRequiredMixin, UpdateView):
    model = Interview
    form_class = BookInterviewForm
    template_name = 'users/book_interview.html'
    success_url = reverse_lazy('users:profile')

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['employee'] = self.request.user.employee
        return kwargs

    def form_valid(self, form):
        # Проверяем, не занят ли слот
        if form.instance.employee:
            messages.error(self.request, "Этот слот уже занят")
            return redirect('users:profile')

        # Назначаем текущего кандидата
        form.instance.employee = self.request.user.employee
        form.instance.is_available = False
        return super().form_valid(form)

    def get_queryset(self):
        return Interview.objects.filter(
            is_available=True,
            datetime__gte=timezone.now()
        )