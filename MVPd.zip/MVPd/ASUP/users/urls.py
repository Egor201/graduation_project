from django.urls import path
from . import views
from .views import (ShiftCalendarView, VacancyСandidate,
                    MySalaryView, BookInterviewView)

app_name = "users"

urlpatterns = [
    path('login/', views.LoginUser.as_view(), name='login'),
    path('logout/', views.logout_users, name='logout'),
    path('register/', views.RegisterUser.as_view(), name='register'),
    path('profile/', views.ProfileUser.as_view(), name='profile'),
    #path('employees/<int:pk>/schedule/', EmployeeScheduleView.as_view(), name='employee_schedule'),
    path('calendar/<int:pk>/', ShiftCalendarView.as_view(), name='shift_calendar'),
    path('calendar/', ShiftCalendarView.as_view(), name='current_shift_calendar'),
    path('calendar/<int:pk>/<int:year>/<int:month>/', ShiftCalendarView.as_view(), name='shift_calendar'),
    path('employees/vacancy/', VacancyСandidate.as_view(), name='vacancy'),
    path('my-salary/', MySalaryView.as_view(), name='my_salary'),
    path('telegram-webhook/', views.telegram_webhook, name='telegram_webhook'),
    path('generate-bind-code/', views.generate_bind_code, name='generate_bind_code'),
    path('book-interview/<int:pk>/', BookInterviewView.as_view(), name='book_interview'),
]