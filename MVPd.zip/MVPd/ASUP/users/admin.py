from django.contrib import admin

# @admin.register(WorkSchedule)
# class WorkScheduleAdmin(admin.ModelAdmin):
#     list_display = ('employee', 'day', 'start_time', 'end_time', 'is_day_off')
#     list_filter = ('  employee', 'day')