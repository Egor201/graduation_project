from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import Group
from main.models import Employee, Vacancy, Interview
from datetime import datetime
from django.utils import timezone


class LoginUserForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField()

    class Meta:
        model = get_user_model()
        fields = ['username', 'password']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'password': forms.PasswordInput(attrs={'class': 'form-control'}),

        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({'class': 'form-control'})
        self.fields['password'].widget.attrs.update({'class': 'form-control'})

class RegisterUserForm(UserCreationForm):
    #username = forms.CharField(label="Логин", widget=forms.TextInput())
    password1 = forms.CharField(label="Пароль", widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    password2 = forms.CharField(label="Повтор пароля", widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    vacancy = forms.ModelChoiceField(
        queryset=Vacancy.objects.filter(status='open'),
        label="Выберите вакансию",
        required=True,
    )
    def save(self, commit=True):
        user = super().save(commit=False)
        data = self.cleaned_data
        user.username = data['email']
        user.employee = Employee.objects.create(full_name = data['first_name'] + " " + data['last_name'],
                                                contact_info = { 'email' : data['email']}, hire_date = datetime.now(),
                                                vacancy=data['vacancy'], test_file=data['vacancy'].test_file)
        data.pop('vacancy')
        if commit:
            user.save()
        try:
            group = Group.objects.get(name='candidate')
            user.groups.add(group)
        except Group.DoesNotExist:
            # Обработка случая, если группа не существует
            pass
        #user.groups.set(Group.objects.get(name='candidate').id)
        return user
    class Meta:
        model = get_user_model()
        fields = ['email', 'first_name', 'last_name']
        labels = {
            'email' : 'E-mail',
            'first_name' : 'Имя',
            'last_name' : 'Фамилия',

        }
        widgets={
            'email': forms.TextInput(attrs={'class': 'form-control'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
        }
    def clean_email(self):
        email = self.cleaned_data ['email']
        if get_user_model().objects.filter(email = email).exists():
            raise forms.ValidationError("E-mail уже есть в базе")
        return email
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['vacancy'].widget.attrs.update({'class': 'form-control'})

class AnswerUploadForm(forms.ModelForm):
    resume = forms.FileField(required=False, widget = forms.FileInput(attrs={'accept': '.pdf,.doc,.docx'}))
    answer_file = forms.FileField(required=False, widget = forms.FileInput(attrs={'accept': '.pdf,.doc,.docx'}))
    # telegram_id = forms.CharField(
    #     label="Telegram ID",
    #     required=False,
    #     widget=forms.TextInput(attrs={
    #         'class': 'form-control',
    #         'placeholder': 'Введите ваш Telegram ID'
    #     })
    # )
    class Meta:
        model = get_user_model()
        fields = ['telegram_id', 'first_name', 'last_name', 'email', 'answer_file', 'resume']
        #fields = ['answer_file', 'resume']

    def clean_answer_file(self):
        file = self.cleaned_data.get('answer_file', 'resume')
        if file:
            if file.size > 10 * 1024 * 1024:  # 10MB limit
                raise forms.ValidationError("Файл слишком большой (макс. 10МБ)")
            if not file.name.endswith(('.pdf', '.doc', '.docx')):
                raise forms.ValidationError("Допустимые форматы: PDF, DOC, DOCX")
        return file
    # def clean_telegram_id(self):
    #     data = self.cleaned_data['telegram_id']
    #     print(data)
    #     if data == '' or (data and not data.startswith('@') and not data.isdigit()):
    #         raise forms.ValidationError("Формат: @username или 123456789")
    #     return data

# Добавим новую форму для профиля
class ProfileForm(forms.ModelForm):
    telegram_id = forms.CharField(
        label="Telegram ID",
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Введите ваш Telegram ID'
        })
    )

    class Meta:
        model = get_user_model()
        fields = ['telegram_id', 'first_name', 'last_name', 'email']

    def clean_telegram_id(self):
        data = self.cleaned_data['telegram_id']
        if data and not data.startswith('@') and not data.isdigit():
            raise forms.ValidationError("Формат: @username или 123456789")
        return data

class BookInterviewForm(forms.ModelForm):
    class Meta:
        model = Interview
        fields = []

    def __init__(self, *args, **kwargs):
        self.employee = kwargs.pop('employee', None)
        super().__init__(*args, **kwargs)

    def save(self, commit=True):
        interview = super().save(commit=False)
        interview.employee = self.employee
        interview.is_available = False
        interview.booked_at = timezone.now()
        if commit:
            interview.save()
        return interview

