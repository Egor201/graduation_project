from django.db import models



#
# class User(ASUP.main.models.User):
#
#     # # ROLES = [
#     # #     ('admin', 'Администратор'),
#     # #     ('hr', 'HR-специалист'),
#     # #     ('employee', 'Сотрудник'),
#     # # ]
#     # #
#     # telegram_id = models.CharField("Telegram ID", max_length=100, unique=True, null=True, default=None)
#     # # role = models.CharField("Роль", max_length=20, choices=ROLES, default='employee')
#     # employee = models.OneToOneField(
#     #     Employee,
#     #     on_delete=models.SET_NULL,
#     #     null=True,
#     #     blank=True,
#     #     verbose_name="Связанный сотрудник"
#     # )
#     #
#     # # Убираем стандартные поля username
#     # # username = None
#     # # USERNAME_FIELD = 'telegram_id'
#     # # REQUIRED_FIELDS = []
#     #
#     # # objects = CustomUserManager()
#     # #
#     # # Исправленные поля groups и user_permissions
#     # # groups = models.ManyToManyField(
#     # #     'auth.Group',
#     # #     related_name='custom_user_groups',
#     # #     blank=True,
#     # #     verbose_name='Группы',
#     # # )
#     # # user_permissions = models.ManyToManyField(
#     # #     'auth.Permission',
#     # #     related_name='custom_user_permissions',
#     # #     blank=True,
#     # #     verbose_name='Права',
#     # # )
#     # #
#     # # def __str__(self):
#     # #     return f"{self.telegram_id} ({self.role})"
#     #
#     # # class Meta:
#     # #     verbose_name = "Пользователь"
#     # #     verbose_name_plural = "Пользователи"
