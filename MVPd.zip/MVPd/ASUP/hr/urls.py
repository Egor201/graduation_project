from django.urls import path
from .views import (HREmployeeListView, HRVacancyListView,
                    HREmployeeDetailView, HREmployeeUpdateView,
                    HRVacancyCreateView, HRVacancyUpdateView,
                    SalaryListView, SalaryUpdateView,
                    EmployeeSalaryReportView, BulkSalaryCreateView,
                    InterviewSlotCreateView, InterviewSlotListView,
                    InterviewSlotUpdateView, ShiftCreateView)

app_name = "hr"

urlpatterns = [
    path('employees/', HREmployeeListView.as_view(), name='employee_list'),
    path('employees/<int:pk>/', HREmployeeDetailView.as_view(), name='employee_detail'),
    path('vacancy/', HRVacancyListView.as_view(), name='vacancy_list'),
    path('employees/<int:pk>/edit/', HREmployeeUpdateView.as_view(), name='employee_edit'),
    path('vacancy/create/', HRVacancyCreateView.as_view(), name='vacancy_create'),
    path('vacancy/<int:pk>/edit/', HRVacancyUpdateView.as_view(), name='vacancy_edit'),
    path('salaries/', SalaryListView.as_view(), name='salary_list'),
    path('salaries/<int:pk>/edit/', SalaryUpdateView.as_view(), name='salary_update'),
    path('employee/<int:pk>/salary-report/', EmployeeSalaryReportView.as_view(), name='employee_salary_report'),
    path('salary/bulk_create/', BulkSalaryCreateView.as_view(), name='bulk_salary_create'),
    path('interviews/', InterviewSlotListView.as_view(), name='interview_list'),
    path('interviews/create/', InterviewSlotCreateView.as_view(), name='interview_create'),
    path('interviews/<int:pk>/update/', InterviewSlotUpdateView.as_view(), name='interview_update'),
    path('shift/add/', ShiftCreateView.as_view(), name='shift_create'),
]