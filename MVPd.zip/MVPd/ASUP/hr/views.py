from django.contrib.auth.mixins import (PermissionRequiredMixin,
                                        LoginRequiredMixin, UserPassesTestMixin)
from django.views.generic import (ListView, DetailView, UpdateView,
                                  CreateView, TemplateView)
from main.models import (Employee, Vacancy,
                         Department, Salary,
                         Interview, WorkShift)
from users.views import ShiftCalendarView
from django.db.models import Q
from .forms import (HREmployeeEditForm, VacancyForm, SalaryForm,
                    BulkSalaryConfigForm, EmployeeSalaryFormSet,
                    EmployeeSalaryForm, InterviewSlotForm,
                    WorkShiftForm)
from django.urls import reverse_lazy
from django.urls import reverse
from datetime import datetime
from collections import defaultdict
from decimal import Decimal
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta
from django.http import HttpResponseRedirect
from .utils import export_to_excel
from django.forms import formset_factory
from django.shortcuts import redirect
from django.db import transaction

class HREmployeeListView(PermissionRequiredMixin, ListView):
    permission_required = "main.change_employee"
    model = Employee
    template_name = 'hr/employee_list.html'
    context_object_name = 'employees'

    def get_queryset(self):
        queryset = super().get_queryset()
        status_filter = self.request.GET.get('status')
        department_filter = self.request.GET.get('department')

        # Группировка статусов
        if status_filter == 'all_candidates':
            selected_statuses = ['new', 'review', 'rejected',  'hired']
            queryset = queryset.filter(
                Q(status=selected_statuses[0]) |
                Q(status=selected_statuses[1]) |
                Q(status=selected_statuses[2]) |
                Q(status=selected_statuses[3])
            )
            #queryset = queryset.filter(status='new' or 'review' or 'rejected'or  'hired')
        elif status_filter in dict(Employee.STATUS_CHOICES):
            queryset = queryset.filter(status=status_filter)

        if department_filter and department_filter != 'all':
            queryset = queryset.filter(department__id=department_filter)

        return queryset.order_by('-user__date_joined')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        selected_department = None
        departments = Department.objects.all()
        current_department = self.request.GET.get('department', 'all')
        if current_department != 'all':
            try:
                selected_department = Department.objects.get(id=int(current_department))
            except (ValueError, Department.DoesNotExist):
                current_department = 'all'  # Сброс при ошибке

        # Считаем количество для каждого статуса
        status_counts = {
            #'candidate_statuses' : employee.status,
            'selected_department': selected_department,
            'current_department': current_department,
            'departments': departments,
            'all_employee':Employee.objects.filter(),
            'all': Employee.objects.filter().count(),
            'employee': Employee.objects.filter(status='employee').count(),
            #'all_candidates': Employee.objects.filter(status__startswith='').count(),
            'candidate_new': Employee.objects.filter(status='new').count(),
            'candidate_review': Employee.objects.filter(status='review').count(),
            'candidate_rejected': Employee.objects.filter(status='rejected').count(),
            'candidate_hired': Employee.objects.filter(status='hired').count(),
            #'all_candidates': Employee.objects.filter(status='new' or 'review' or 'rejected' or 'hired').count(),
            'all_candidates': Employee.objects.filter().count() - Employee.objects.filter(status='employee').count(),
        }

        context.update({
            'current_status': self.request.GET.get('status', 'all'),
            'status_counts': status_counts,
        })
        return context

    def get(self, request, *args, **kwargs):
        if request.GET.get('export') == 'excel':
            return self.export_excel()
        return super().get(request, *args, **kwargs)

    def export_excel(self):
        columns = [
            ('full_name', 'ФИО', 30),
            ('position.title', 'Должность', 25),
            ('department.name', 'Подразделение', 20),
            ('hire_date', 'Дата приема', 15),
            ('status', 'Статус', 15),
            ('contact_info', 'Контакты', 40),
        ]
        return export_to_excel(
            self.get_queryset(),
            columns,
            'Сотрудники'
        )

class HRVacancyListView(PermissionRequiredMixin, ListView):
    permission_required = "main.view_vacancy"
    model = Vacancy
    template_name = 'hr/vacancy_list.html'
    context_object_name = 'vacancies'

    def get(self, request, *args, **kwargs):
        if request.GET.get('export') == 'excel':
            return self.export_excel()
        return super().get(request, *args, **kwargs)

    def export_excel(self):
        columns = [
            ('title', 'Вакансия', 30),
            ('description', 'Описание', 50),
            ('status', 'Статус', 15),
            ('publish_date', 'Дата публикации', 15),
            ('close_date', 'Дата закрытия', 15),
            ('hr.username', 'Ответственный HR', 20),
        ]
        return export_to_excel(
            self.get_queryset(),
            columns,
            'Вакансии'
        )

class HREmployeeDetailView(PermissionRequiredMixin, DetailView):
    permission_required = "main.change_employee"
    model = Employee
    template_name = 'hr/employee_detail.html'

class HREmployeeUpdateView(PermissionRequiredMixin, UpdateView):
    permission_required = [
        'main.change_employee',
        'main.change_user'
    ]
    model = Employee
    form_class = HREmployeeEditForm
    template_name = 'hr/employee_edit.html'
    success_url = reverse_lazy('hr:employee_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['status_choices'] = Employee.STATUS_CHOICES
        return context

class HRVacancyCreateView(PermissionRequiredMixin, CreateView):
    permission_required = "main.add_vacancy"
    model = Vacancy
    form_class = VacancyForm
    template_name = 'hr/vacancy_form.html'

    def form_valid(self, form):
        form.instance.publish_date = datetime.now()
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('hr:vacancy_list')

class HRVacancyUpdateView(PermissionRequiredMixin, UpdateView):
    permission_required = "main.change_vacancy"
    model = Vacancy
    form_class = VacancyForm
    template_name = 'hr/vacancy_form.html'


    def get_success_url(self):
        return reverse('hr:vacancy_list')

class SalaryListView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    model = Salary
    template_name = 'hr/salary_list.html'
    context_object_name = 'salaries'
    paginate_by = 12  # 12 месяцев на страницу

    def test_func(self):
        return self.request.user.groups.filter(name='hr').exists()

    def get_queryset(self):
        return Salary.get_monthly_summary()



    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Добавляем читаемые названия месяцев
        months = {
            1: 'Январь', 2: 'Февраль', 3: 'Март', 4: 'Апрель',
            5: 'Май', 6: 'Июнь', 7: 'Июль', 8: 'Август',
            9: 'Сентябрь', 10: 'Октябрь', 11: 'Ноябрь', 12: 'Декабрь'
        }

        for item in context['salaries']:
            item['month_name'] = months.get(item['month'])
            item['year_month'] = f"{months.get(item['month'])} {item['year']}"

        return context

    def get(self, request, *args, **kwargs):
        if request.GET.get('export') == 'excel':
            return self.export_excel()
        return super().get(request, *args, **kwargs)

    def export_excel(self):
        columns = [
            ('year_month', 'Период', 20),
            ('total_base', 'Сумма окладов', 15),
            ('total_bonus', 'Сумма премий', 15),
            ('total_allowances', 'Сумма надбавок', 15),
            ('total_tax', 'Сумма НДФЛ', 15),
            ('total_insurance', 'Сумма страховых', 15),
            ('total_salary', 'Итого выплат', 15),
            ('calculation_date', 'Дата расчета', 15),
        ]
        return export_to_excel(
            self.get_queryset(),
            columns,
            'Зарплаты_по_месяцам'
        )

class SalaryUpdateView(PermissionRequiredMixin, UpdateView):
    model = Salary
    permission_required = "main.change_salary"
    form_class = SalaryForm  # Используем нашу кастомную форму
    template_name = 'hr/salary_form.html'
    success_url = reverse_lazy('hr:salary_list')


    # def test_func(self):
    #     return self.request.user.groups.filter(name='hr').exists()

class EmployeeSalaryReportView(LoginRequiredMixin, UserPassesTestMixin, TemplateView):
    template_name = 'hr/employee_salary_report.html'

    def test_func(self):
        return self.request.user.groups.filter(name='hr').exists() or \
            self.request.user.employee.pk == self.kwargs['pk']

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        employee = Employee.objects.get(pk=self.kwargs['pk'])

        # Получаем все зарплаты сотрудника
        salaries = Salary.objects.filter(employee=employee).order_by('-year', '-month')

        # Группируем данные по годам
        report_data = defaultdict(lambda: {
            'months': [],
            'total_income': Decimal('0'),
            'total_tax': Decimal('0'),
            'total_insurance': Decimal('0'),
            'total_net': Decimal('0'),
            'tax_rate': '0.0'
        })

        for salary in salaries:
            year_data = report_data[salary.year]
            month_data = {
                'month': salary.get_month_display(),
                'income': salary.base_salary + salary.bonus + salary.allowances,
                'tax': salary.tax,
                'insurance': salary.insurance,
                'net': salary.total_salary
            }

            year_data['months'].append(month_data)
            year_data['total_income'] += month_data['income']
            year_data['total_tax'] += month_data['tax']
            year_data['total_insurance'] += month_data['insurance']
            year_data['total_net'] += month_data['net']

        # Рассчитываем эффективную ставку НДФЛ
        for year, data in report_data.items():
            try:
                tax_rate = (data['total_tax'] / data['total_income'] * 100).quantize(Decimal('0.1'))
            except ZeroDivisionError:
                tax_rate = Decimal('0.0')
            data['tax_rate'] = f"{tax_rate}%"

        context.update({
            'employee': employee,
            'report_data': sorted(report_data.items(), reverse=True),
            'current_year': datetime.now().year
        })
        return context

class BulkSalaryCreateView(PermissionRequiredMixin, TemplateView):
    permission_required = "main.add_salary"
    template_name = 'hr/bulk_salary_create.html'
    form_class = EmployeeSalaryFormSet

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        employees = Employee.objects.filter(status='employee')
        context['employees'] = employees

        if self.request.method == 'POST' and 'load' in self.request.POST:
            config_form = BulkSalaryConfigForm(self.request.POST)
            if config_form.is_valid():
                year = config_form.cleaned_data['year']
                month = config_form.cleaned_data['month']

                SalaryFormSet = formset_factory(
                    EmployeeSalaryForm,
                    extra=0
                )

                initial_data = []
                for employee in employees:
                    try:
                        salary = Salary.objects.get(
                            employee=employee,
                            year=year,
                            month=month
                        )
                    except Salary.DoesNotExist:
                        salary = Salary(
                            employee=employee,
                            year=year,
                            month=month,
                            base_salary=employee.position.base_salary if employee.position else 0
                        )

                    initial_data.append({
                        'employee': employee.id,

                        'base_salary': salary.base_salary,
                        'bonus': salary.bonus,
                        'allowances': salary.allowances,
                        # 'tax': salary.tax,
                        # 'insurance': salary.insurance,
                    })

                context['formset'] = SalaryFormSet(initial=initial_data)
                context['config_form'] = config_form
                context['zip_data'] = zip(employees, context['formset'])
                return context

        context['config_form'] = BulkSalaryConfigForm()
        context['formset'] = formset_factory(EmployeeSalaryForm, extra=0)()
        context['zip_data'] = zip(employees, context['formset'])

        return context

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        context = self.get_context_data()
        config_form = BulkSalaryConfigForm(request.POST)
        SalaryFormSet = formset_factory(EmployeeSalaryForm)

        if 'save' in request.POST:
            formset = SalaryFormSet(request.POST)

            if config_form.is_valid() and formset.is_valid():
                year = config_form.cleaned_data['year']
                month = config_form.cleaned_data['month']

                for form in formset:
                    employee_id = form.cleaned_data.get('employee')
                    if employee_id:
                        employee = Employee.objects.get(id=employee_id)
                        Salary.objects.update_or_create(
                            employee=employee,
                            year=year,
                            month=month,
                            defaults={
                                'base_salary': form.cleaned_data['base_salary'],
                                'bonus': form.cleaned_data['bonus'],
                                'allowances': form.cleaned_data['allowances'],
                                # 'tax': form.cleaned_data['tax'],
                                # 'insurance': form.cleaned_data['insurance'],
                            }
                        )

                messages.success(request, "Изменения успешно сохранены!")
                return redirect('hr:salary_list')

        return self.render_to_response(context)

class InterviewSlotCreateView(PermissionRequiredMixin, CreateView):
    permission_required = "main.add_interview"
    model = Interview
    form_class = InterviewSlotForm
    template_name = 'hr/interview_form.html'

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        form.hr = self.request.user.employee
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('hr:interview_list')

class InterviewSlotListView(PermissionRequiredMixin, ListView):
    permission_required = "main.view_interview"
    model = Interview
    template_name = 'hr/interview_list.html'
    paginate_by = 20

    def get_queryset(self):
        now = timezone.now()
        qs = super().get_queryset().filter(hr=self.request.user)

        # Фильтр по дате
        date_filter = self.request.GET.get('date_filter', 'all')
        if date_filter == 'today':
            qs = qs.filter(datetime__date=now.date())
        elif date_filter == 'tomorrow':
            qs = qs.filter(datetime__date=now.date() + timedelta(days=1))
        elif date_filter == 'week':
            start_week = now.date() - timedelta(days=now.weekday())
            end_week = start_week + timedelta(days=6)
            qs = qs.filter(datetime__date__range=[start_week, end_week])

        # Фильтр по статусу слота
        slot_status = self.request.GET.get('slot_status')
        if slot_status == 'free':
            qs = qs.filter(employee__isnull=True)
        elif slot_status == 'booked':
            qs = qs.filter(employee__isnull=False)

        return qs.order_by('datetime')

    def get(self, request, *args, **kwargs):
        if request.GET.get('export') == 'excel':
            return self.export_excel()
        return super().get(request, *args, **kwargs)

    def export_excel(self):
        columns = [
            ('employee.full_name', 'Кандидат', 30),
            ('hr.username', 'HR', 20),
            ('datetime', 'Дата и время', 20),
            ('platform', 'Платформа', 15),
            ('link', 'Ссылка', 40),
            ('interview_type', 'Тип собеседования', 25),
            ('is_available', 'Статус слота', 15),
        ]
        return export_to_excel(
            self.get_queryset(),
            columns,
            'Собеседования'
        )

class InterviewSlotUpdateView(PermissionRequiredMixin, UpdateView):
    permission_required = "main.change_interview"
    model = Interview
    form_class = InterviewSlotForm
    template_name = 'hr/interview_form.html'

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def get_success_url(self):
        return reverse('hr:interview_list')

class ShiftCreateView(CreateView):
    form_class = WorkShiftForm
    template_name = 'hr/shift_form.html'
    success_url = reverse_lazy('hr:employee_list')

    def get_initial(self):
        initial = super().get_initial()
        employee_id = self.request.GET.get('employee')
        if employee_id:
            try:
                initial['employee'] = employee_id
            except:
                pass
        return initial

    def form_valid(self, form):
        schedule_type = form.cleaned_data['schedule_type']

        # Для одиночной смены - стандартное поведение
        if schedule_type == 'single':
            self.object = form.save()
            employee = form.cleaned_data['employee']
            messages.success(
                self.request,
                f"Смена для {employee.full_name} успешно добавлена"
            )
            return super().form_valid(form)

        # Для периодических смен
        if form.is_valid():
            self.handle_recurrent_shifts(form)
            return HttpResponseRedirect(self.get_success_url())

        return self.form_invalid(form)

    def handle_recurrent_shifts(self, form):
        data = form.cleaned_data
        employee = data['employee']
        start_date = data['date']
        end_date = data['end_date']
        start_time = data['start_time']
        end_time = data['end_time']
        shift_type = data['shift_type']
        comment = data['comment']
        schedule_type = data['schedule_type']
        custom_pattern = data.get('custom_pattern', '')

        # Определяем шаблон графика
        if schedule_type == '5/2':
            pattern = '1111100'  # 5 рабочих, 2 выходных
        elif schedule_type == '2/2':
            pattern = '1100'  # 2 рабочих, 2 выходных
        elif schedule_type == '3/3':
            pattern = '111000'  # 3 рабочих, 3 выходных
        elif schedule_type == 'custom':
            pattern = custom_pattern

        created_count = 0
        current_date = start_date
        pattern_index = 0
        pattern_length = len(pattern)

        # Список для массового создания смен
        shifts_to_create = []

        # Получаем уже существующие смены
        existing_shifts = WorkShift.objects.filter(
            employee=employee,
            date__gte=start_date,
            date__lte=end_date
        ).values_list('date', flat=True)

        # Собираем смены для создания
        total_days = (end_date - start_date).days + 1
        work_days_in_period = 0

        for i in range(total_days):
            # Пропускаем выходные (0 в шаблоне)
            if pattern[pattern_index] == '1':
                work_days_in_period += 1

                # Пропускаем даты, где смена уже существует
                if current_date not in existing_shifts:
                    shifts_to_create.append(WorkShift(
                        employee=employee,
                        date=current_date,
                        start_time=start_time,
                        end_time=end_time,
                        shift_type=shift_type,
                        comment=comment
                    ))

            # Переходим к следующему дню и следующему символу в шаблоне
            current_date += timedelta(days=1)
            pattern_index = (pattern_index + 1) % pattern_length

        # Массовое создание смен
        if shifts_to_create:
            WorkShift.objects.bulk_create(shifts_to_create)
            created_count = len(shifts_to_create)

        # Рассчитываем сколько смен не было создано
        skipped = work_days_in_period - created_count - len(existing_shifts)

        messages.success(
            self.request,
            f"Создано {created_count} смен для {employee.full_name} по графику {schedule_type}"
        )

        if skipped > 0:
            messages.info(
                self.request,
                f"{skipped} смен не создано (уже существуют в системе)"
            )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['employee_id'] = self.request.GET.get('employee')
        return context

    def get_success_url(self):
        return reverse_lazy('hr:employee_list')
