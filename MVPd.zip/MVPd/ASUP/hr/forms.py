from django import forms
from django.contrib.auth import get_user_model
from main.models import (Employee, Vacancy,
                         Salary, Interview,
                         # Application,
                         WorkShift)
from django.forms import inlineformset_factory
from django.utils import timezone
from datetime import timedelta
from django.core.exceptions import ValidationError
import re


User = get_user_model()

class HREmployeeEditForm(forms.ModelForm):

    first_name = forms.CharField(label='Имя', max_length=150, required=True)
    last_name = forms.CharField(label='Фамилия', max_length=150, required=True)
    email = forms.EmailField(label='Email', required=True)

    class Meta:
        model = Employee
        fields = [
            'position',
            'department',
            'hire_date',
            'status',
            'vacancy',
            'test_file',
            'answer_file',
            'contact_info'
        ]
        widgets = {
            'hire_date': forms.DateInput(),
            'contact_info': forms.Textarea(attrs={'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['first_name'].widget.attrs.update({'class': 'form-control'})
        self.fields['last_name'].widget.attrs.update({'class': 'form-control'})
        self.fields['email'].widget.attrs.update({'class': 'form-control'})
        self.fields['position'].widget.attrs.update({'class': 'form-control'})
        self.fields['department'].widget.attrs.update({'class': 'form-control'})
        self.fields['hire_date'].widget.attrs.update({'class': 'form-control'})
        self.fields['status'].widget.attrs.update({'class': 'form-control'})
        self.fields['vacancy'].widget.attrs.update({'class': 'form-control'})
        self.fields['test_file'].widget.attrs.update({'class': 'form-control'})
        self.fields['answer_file'].widget.attrs.update({'class': 'form-control'})
        self.fields['contact_info'].widget.attrs.update({'class': 'form-control'})
        if self.instance.user:
            user = self.instance.user
            self.fields['first_name'].initial = user.first_name
            self.fields['last_name'].initial = user.last_name
            self.fields['email'].initial = user.email


    def clean_email(self):
        email = self.cleaned_data['email']
        user = self.instance.user
        if User.objects.exclude(pk=user.pk).filter(email=email).exists():
            raise forms.ValidationError("Этот email уже используется")
        return email

    def save(self, commit=True):
        employee = super().save(commit=False)
        user = employee.user
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.email = self.cleaned_data['email']
        employee.full_name = user.first_name +" "+ user.last_name
        #print(user.first_name)
        if commit:
            user.save()
            employee.save()
        return employee

class VacancyForm(forms.ModelForm):
    class Meta:
        model = Vacancy
        fields = [
            'title',
            'description',
            'hr',
            'status',
            'close_date',
            'test_file',
            'hh_external_id'
        ]
        widgets = {
            'close_date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 4}),
            'hr': forms.Select(attrs={'class': 'form-control'}),
        }
        labels = {
            'hh_external_id': 'ID на hh.ru',
            'test_file': 'Тестовое задание'
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['hr'].queryset = get_user_model().objects.filter(groups__name='hr')
        self.fields['title'].widget.attrs.update({'class': 'form-control'})
        self.fields['description'].widget.attrs.update({'class': 'form-control'})
        self.fields['status'].widget.attrs.update({'class': 'form-control'})
        self.fields['close_date'].widget.attrs.update({'class': 'form-control'})
        self.fields['test_file'].widget.attrs.update({'class': 'form-control'})
        self.fields['hh_external_id'].widget.attrs.update({'class': 'form-control'})

class SalaryForm(forms.ModelForm):
    year = forms.TypedChoiceField(
        label="Год",
        choices=[(year, year) for year in range(2020, 2030)],
        coerce=int,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    class Meta:
        model = Salary
        fields = ['year', 'month', 'base_salary', 'bonus', 'allowances', 'tax', 'insurance']
        widgets = {
            'month': forms.Select(attrs={'class': 'form-select'}),
            'base_salary': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'bonus': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'allowances': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'tax': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'insurance': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
        }
        labels = {
            'base_salary': 'Основной оклад',
            'bonus': 'Премия',
            'allowances': 'Надбавки',
            'tax': 'НДФЛ',
            'insurance': 'Страховые взносы'
        }

class BulkSalaryConfigForm(forms.Form):
    year = forms.TypedChoiceField(
        label="Год",
        choices=[(year, year) for year in range(2023, 2030)],
        coerce=int,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    month = forms.TypedChoiceField(
        label="Месяц",
        choices=Salary._meta.get_field('month').choices,
        coerce=int,
        widget=forms.Select(attrs={'class': 'form-select'})
    )

class EmployeeSalaryForm(forms.Form):
    employee = forms.IntegerField(widget=forms.HiddenInput())
    base_salary = forms.DecimalField(
        label="Оклад",
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )
    bonus = forms.DecimalField(
        label="Премия",
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )
    allowances = forms.DecimalField(
        label="Надбавки",
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )
    # tax = forms.DecimalField(
    #     label="НДФЛ",
    #     max_digits=10,
    #     decimal_places=2,
    #     widget=forms.NumberInput(attrs={'class': 'form-control'})
    # )
    # insurance = forms.DecimalField(
    #     label="Страховые",
    #     max_digits=10,
    #     decimal_places=2,
    #     widget=forms.NumberInput(attrs={'class': 'form-control'})
    # )


# class InterviewSlotForm(forms.ModelForm):
#     class Meta:
#         model = Interview
#         fields = [
#             # 'application',
#             'interview_type',
#             'datetime',
#             'duration',
#             'platform',
#             'link',
#             'hr',
#             'is_available',
#             'notes'
#         ]
#         widgets = {
#             'datetime': forms.DateTimeInput(
#                 attrs={
#                     'type': 'datetime-local',
#                     'min': timezone.now().strftime('%Y-%m-%dT%H:%M')
#                 }
#             ),
#             'notes': forms.Textarea(attrs={'rows': 3}),
#         }
#     def __init__(self, *args, **kwargs):
#         user = kwargs.pop('user', None)
#         super().__init__(*args, **kwargs)
#         self.fields['notes'].widget.attrs.update({'class': 'form-control'})
#         #self.fields['is_available'].widget.attrs.update({'class': 'form-control'})
#         self.fields['hr'].widget.attrs.update({'class': 'form-control'})
#         self.fields['link'].widget.attrs.update({'class': 'form-control'})
#         self.fields['platform'].widget.attrs.update({'class': 'form-control'})
#         self.fields['duration'].widget.attrs.update({'class': 'form-control'})
#         self.fields['datetime'].widget.attrs.update({'class': 'form-control'})
#         self.fields['interview_type'].widget.attrs.update({'class': 'form-control'})
#         # self.fields['application'].widget.attrs.update({'class': 'form-control'})
#         # self.fields['application'].required = False
#         # self.fields['application'].empty_label = "Свободный слот (без привязки)"
#         # # Фильтруем отклики только по вакансиям текущего HR
#         # if user and user.groups.filter(name='hr').exists():
#         #     self.fields['application'].queryset = Application.objects.filter(
#         #         vacancy__hr=user
#         #     )
#         #     self.fields['hr'].initial = user
#         #     self.fields['hr'].disabled = True
#
#     def clean(self):
#         cleaned_data = super().clean()
#         start = cleaned_data.get('datetime')
#         duration = cleaned_data.get('duration')
#         hr = cleaned_data.get('hr')
#
#         if start and duration and hr:
#             end = start + timedelta(minutes=duration)
#             # Проверка на пересечение с существующими интервью
#             overlapping = Interview.objects.filter(
#                 hr=hr,
#                 datetime__lt=end,
#                 datetime__gte=start - timedelta(minutes=30)
#             ).exclude(pk=self.instance.pk)
#
#             if overlapping.exists():
#                 self.add_error(
#                     'datetime',
#                     "На это время уже есть собеседование у HR"
#                 )

class InterviewSlotForm(forms.ModelForm):
    class Meta:
        model = Interview
        fields = [
            'employee',  # Добавляем поле для выбора кандидата
            'interview_type',
            'datetime',
            'duration',
            'platform',
            'link',
            'is_available',
            'notes',
            'hr'
        ]
        widgets = {
            'datetime': forms.DateTimeInput(
                attrs={
                    'type': 'datetime-local',
                    'min': timezone.now().strftime('%Y-%m-%dT%H:%M')
                }
            ),
            'notes': forms.Textarea(attrs={'rows': 3}),
            'employee': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

        # Фильтруем только кандидатов (не сотрудников)
        self.fields['employee'].queryset = Employee.objects.filter(
            status__in=['new', 'review', 'hired']
        )
        self.fields['employee'].required = False
        self.fields['employee'].empty_label = "Выберите кандидата"

        # Настройка виджетов
        for field in ['notes', 'link', 'platform', 'duration', 'datetime', 'interview_type']:
            self.fields[field].widget.attrs.update({'class': 'form-control'})

        # Для HR устанавливаем текущего пользователя
        if user:
            self.fields['hr'].initial = user
            self.fields['hr'].disabled = True

    def clean(self):
        cleaned_data = super().clean()
        start = cleaned_data.get('datetime')
        duration = cleaned_data.get('duration')
        hr = cleaned_data.get('hr')

        if start and duration and hr:
            end = start + timedelta(minutes=duration)
            overlapping = Interview.objects.filter(
                hr=hr,
                datetime__lt=end,
                datetime__gte=start - timedelta(minutes=30)
            ).exclude(pk=self.instance.pk)

            if overlapping.exists():
                self.add_error(
                    'datetime',
                    "На это время уже есть собеседование у HR"
                )


class WorkShiftForm(forms.ModelForm):
    SCHEDULE_CHOICES = [
        ('single', 'Одиночная смена'),
        ('5/2', '5/2 (Пятидневка)'),
        ('2/2', '2/2 (Два через два)'),
        ('3/3', '3/3 (Три через три)'),
        ('custom', 'Свой график'),
    ]

    schedule_type = forms.ChoiceField(
        choices=SCHEDULE_CHOICES,
        initial='single',
        label='Тип графика',
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'}))

    custom_pattern = forms.CharField(
        required=False,
        max_length=50,
        label='Свой график (например: 1100)',
        help_text='1 - рабочий день, 0 - выходной. Пример: 1100 - два рабочих, два выходных')

    end_date = forms.DateField(
        required=False,
        label='Конечная дата графика',
        widget=forms.DateInput(attrs={'type': 'date'}))

    class Meta:
        model = WorkShift
        fields = ['employee', 'date', 'start_time', 'end_time', 'shift_type', 'comment']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'start_time': forms.TimeInput(attrs={'type': 'time'}),
            'end_time': forms.TimeInput(attrs={'type': 'time'}),
            'employee': forms.Select(attrs={'class': 'form-select'}),
            'shift_type': forms.Select(attrs={'class': 'form-select'}),
            'comment': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

    def clean(self):
        cleaned_data = super().clean()
        schedule_type = cleaned_data.get('schedule_type')
        end_date = cleaned_data.get('end_date')
        start_date = cleaned_data.get('date')
        custom_pattern = cleaned_data.get('custom_pattern')

        # Проверка времени
        start_time = cleaned_data.get('start_time')
        end_time = cleaned_data.get('end_time')
        if start_time and end_time and start_time >= end_time:
            raise ValidationError("Время окончания смены должно быть позже начала")

        # Проверка для периодического графика
        if schedule_type != 'single':
            if not end_date:
                raise ValidationError("Для периодического графика укажите конечную дату")

            if end_date <= start_date:
                raise ValidationError("Конечная дата должна быть позже начальной")

            if schedule_type == 'custom' and not custom_pattern:
                raise ValidationError("Для своего графика укажите шаблон")

            if schedule_type == 'custom' and custom_pattern:
                if not re.match(r'^[01]+$', custom_pattern):
                    raise ValidationError("Шаблон должен содержать только 0 и 1")

        return cleaned_data


EmployeeSalaryFormSet = inlineformset_factory(
    Employee,
    Salary,
    form=EmployeeSalaryForm,
    fields=['base_salary', 'bonus', 'allowances'],  # Указание полей для formset
    extra=0,
    can_delete=False
)


