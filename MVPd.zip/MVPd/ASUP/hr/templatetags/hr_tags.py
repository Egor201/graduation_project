# hr/templatetags/hr_tags.py
from django import template

register = template.Library()

@register.filter(name='zip')
def zip_lists(value1, value2):
    return zip(value1, value2)