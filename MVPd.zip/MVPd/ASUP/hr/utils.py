# hr/utils.py
from django.http import HttpResponse
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter
from django.db.models import Model
from datetime import datetime


def export_to_excel(queryset, columns, filename):
    wb = Workbook()
    ws = wb.active
    ws.title = "Данные"

    # Заголовки
    header_font = Font(bold=True)
    header_alignment = Alignment(horizontal='center')

    for col_num, col_data in enumerate(columns, 1):
        title = col_data[1]  # Второй элемент - заголовок
        width = col_data[2]  # Третий элемент - ширина

        cell = ws.cell(row=1, column=col_num, value=title)
        cell.font = header_font
        cell.alignment = header_alignment
        ws.column_dimensions[get_column_letter(col_num)].width = width

    # Данные
    for row_num, obj in enumerate(queryset, 2):
        for col_num, col_data in enumerate(columns, 1):
            field = col_data[0]  # Первый элемент - поле
            value = get_nested_attr(obj, field)

            # Для полей с choices получаем читаемое значение
            if hasattr(obj, f'get_{field}_display'):
                value = getattr(obj, f'get_{field}_display')()

            ws.cell(row=row_num, column=col_num, value=value)

    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="{filename}.xlsx"'
    wb.save(response)
    return response


def get_nested_attr(obj, attr_path):
    """Получает вложенные атрибуты объекта"""
    value = obj
    for attr in attr_path.split('.'):
        if value is None:
            return ''

        if hasattr(value, attr):
            value = getattr(value, attr)
        elif isinstance(value, dict) and attr in value:
            value = value[attr]
        else:
            return ''

    # Форматирование специальных типов
    if isinstance(value, Model):
        return str(value)
    if isinstance(value, datetime):
        return value.strftime('%d.%m.%Y %H:%M')
    if isinstance(value, bool):
        return 'Да' if value else 'Нет'
    if value is None:
        return ''

    return value