# utils/decorators.py
from django.contrib.auth.decorators import user_passes_test
from django.core.exceptions import PermissionDenied

def role_required(roles):
    def check_role(user):
        if user.role in roles:
            return True
        raise PermissionDenied("Доступ запрещен")
    return user_passes_test(check_role)