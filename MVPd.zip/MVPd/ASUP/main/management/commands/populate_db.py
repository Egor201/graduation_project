import random
import json
from datetime import datetime, timedelta
from django.utils import timezone
from django.core.management.base import BaseCommand
from main.models import (
    Department, Position, Vacancy, Employee,
    Salary, WorkShift, WorkHistory, User, Notification, Interview
)
from django.contrib.auth.models import Group
from decimal import Decimal
from django.contrib.auth.hashers import make_password


class Command(BaseCommand):
    help = 'Populate database with test data'

    def handle(self, *args, **kwargs):
        self.stdout.write("Creating departments...")
        departments = self.create_departments()

        self.stdout.write("Creating positions...")
        positions = self.create_positions()

        self.stdout.write("Creating vacancies...")
        vacancies = self.create_vacancies(positions, departments)

        self.stdout.write("Creating employees...")
        employees = self.create_employees(positions, departments, vacancies)

        # self.stdout.write("Creating users...")
        # users = self.create_users(employees)

        self.stdout.write("Creating salaries...")
        self.create_salaries(employees)

        self.stdout.write("Creating work shifts...")
        self.create_work_shifts(employees)

        self.stdout.write("Creating work history...")
        self.create_work_history(employees, departments, positions)

        self.stdout.write("Creating interviews...")
        self.create_interviews(employees, users)

        # self.stdout.write("Creating notifications...")
        # self.create_notifications(users)

        self.stdout.write(self.style.SUCCESS('Database populated successfully!'))

    def create_departments(self):
        departments = [
            "Отдел разработки",
            "Отдел продаж",
            "Отдел маркетинга",
            "Отдел кадров"
        ]
        return [Department.objects.create(name=name) for name in departments]

    def create_positions(self):
        positions = [
            {"title": "Разработчик Python", "salary": 120000},
            {"title": "Менеджер по продажам", "salary": 80000},
            {"title": "Маркетолог", "salary": 70000},
            {"title": "HR-специалист", "salary": 65000},
            {"title": "Тестировщик", "salary": 90000},
            {"title": "Дизайнер", "salary": 85000},
            {"title": "Аналитик", "salary": 110000},
        ]
        created = []
        for pos in positions:
            created.append(Position.objects.create(
                title=pos["title"],
                base_salary=pos["salary"]
            ))

        return created

    def create_vacancies(self, positions, departments):
        vacancies = [
            {
                "title": "Junior Python Developer",
                "description": "Требуется начинающий разработчик Python",
                "status": "open",
                "department": departments[0]
            },
            {
                "title": "Менеджер по продажам",
                "description": "Работа с ключевыми клиентами",
                "status": "open",
                "department": departments[1]
            },
            {
                "title": "Старший маркетолог",
                "description": "Разработка маркетинговых стратегий",
                "status": "closed",
                "department": departments[2]
            },
            {
                "title": "HR-менеджер",
                "description": "Подбор IT-персонала",
                "status": "open",
                "department": departments[3]
            },
            {
                "title": "Тестировщик мобильных приложений",
                "description": "Тестирование iOS/Android приложений",
                "status": "open",
                "department": departments[0]
            }
        ]

        created = []
        for vac in vacancies:
            vacancy = Vacancy.objects.create(
                title=vac["title"],
                description=vac["description"],
                status=vac["status"],
                publish_date=timezone.now() - timedelta(days=random.randint(1, 30)),
                department=vac["department"]
            )
            created.append(vacancy)
        return created

    def create_employees(self, positions, departments, vacancies):
        employees = []

        # Создаем группы ролей (если они ещё не существуют)
        hr_group, _ = Group.objects.get_or_create(name='hr')
        employee_group, _ = Group.objects.get_or_create(name='employee')
        candidate_group, _ = Group.objects.get_or_create(name='candidate')

        # Действующие сотрудники
        for i in range(1, 21):
            first_name = random.choice(["Иван", "Алексей", "Дмитрий", "Андрей", "Сергей"])
            last_name = random.choice(["Иванов", "Петров", "Сидоров", "Кузнецов", "Смирнов"])

            # Создаем сотрудника
            emp = Employee.objects.create(
                full_name=f"{last_name} {first_name}",
                contact_info=json.dumps({
                    "phone": f"+7916{random.randint(1000000, 9999999)}",
                    "email": f"employee{i}@company.com"
                }),
                position=random.choice(positions),
                department=random.choice(departments),
                hire_date=timezone.now() - timedelta(days=random.randint(365, 1825)),
                status="employee"
            )
            employees.append(emp)

            # Создаем пользователя
            username = f"user{emp.id}"
            contact_data = json.loads(emp.contact_info)
            name_parts = emp.full_name.split()

            user = User.objects.create_user(
                username=username,
                password="testpassword",
                email=contact_data["email"],
                first_name=name_parts[1] if len(name_parts) > 1 else "",
                last_name=name_parts[0],
                employee=emp
            )

            # Назначаем роль и права
            if emp.position and "hr" in emp.position.title.lower():
                user.groups.add(hr_group)
                user.is_staff = True
                user.save()
            else:
                user.groups.add(employee_group)

        # Кандидаты
        for i in range(1, 11):
            first_name = random.choice(["Анна", "Елена", "Ольга", "Мария", "Наталья"])
            last_name = random.choice(["Иванова", "Петрова", "Сидорова", "Кузнецова", "Смирнова"])
            status = random.choice(["new", "review", "rejected", "hired"])

            # Создаем сотрудника-кандидата
            emp = Employee.objects.create(
                full_name=f"{last_name} {first_name}",
                contact_info=json.dumps({
                    "phone": f"+7916{random.randint(1000000, 9999999)}",
                    "email": f"candidate{i}@company.com"
                }),
                position=None,
                department=None,
                hire_date=timezone.now(),
                status=status,
                vacancy=random.choice(vacancies) if status != "rejected" else None
            )
            employees.append(emp)

            # Создаем пользователя для кандидата
            username = f"user{emp.id}"
            contact_data = json.loads(emp.contact_info)
            name_parts = emp.full_name.split()

            user = User.objects.create_user(
                username=username,
                password="testpassword",
                email=contact_data["email"],
                first_name=name_parts[1] if len(name_parts) > 1 else "",
                last_name=name_parts[0],
                employee=emp
            )

            # Назначаем роль кандидата
            user.groups.add(candidate_group)

        return employees
    # def create_employees(self, positions, departments, vacancies):
    #     # Действующие сотрудники
    #     employees = []
    #     for i in range(1, 21):
    #         first_name = random.choice(["Иван", "Алексей", "Дмитрий", "Андрей", "Сергей"])
    #         last_name = random.choice(["Иванов", "Петров", "Сидоров", "Кузнецов", "Смирнов"])
    #         emp = Employee.objects.create(
    #             full_name=f"{last_name} {first_name}",
    #             contact_info=json.dumps({
    #                 "phone": f"+7916{random.randint(1000000, 9999999)}",
    #                 "email": f"employee{i}@company.com"
    #             }),
    #             position=random.choice(positions),
    #             department=random.choice(departments),
    #             hire_date=timezone.now() - timedelta(days=random.randint(365, 1825)),
    #             status="employee"
    #         )
    #         employees.append(emp)
    #
    #     # Кандидаты
    #     for i in range(1, 11):
    #         first_name = random.choice(["Анна", "Елена", "Ольга", "Мария", "Наталья"])
    #         last_name = random.choice(["Иванова", "Петрова", "Сидорова", "Кузнецова", "Смирнова"])
    #         status = random.choice(["new", "review", "rejected", "hired"])
    #
    #         emp = Employee.objects.create(
    #             full_name=f"{last_name} {first_name}",
    #             contact_info=json.dumps({
    #                 "phone": f"+7916{random.randint(1000000, 9999999)}",
    #                 "email": f"candidate{i}@company.com"
    #             }),
    #             position=None,
    #             department=None,
    #             hire_date=timezone.now(),
    #             status=status,
    #             vacancy=random.choice(vacancies) if status != "rejected" else None
    #         )
    #         employees.append(emp)
    #
    #     return employees
    #
    # def create_users(self, employees):
    #     users = []
    #     # Создаем пользователей только для действующих сотрудников (первые 20)
    #     for emp in employees:
    #         username = f"user{emp.id}"
    #         user = User.objects.create_user(
    #             username=username,
    #             password="testpassword",
    #             email=emp.contact_info["email"] if isinstance(emp.contact_info, dict) else json.loads(emp.contact_info)[
    #                 "email"],
    #             first_name=emp.full_name.split()[1],
    #             last_name=emp.full_name.split()[0],
    #             employee=emp,
    #
    #             #telegram_id=100000000 + i
    #         )
    #
    #         # Для HR-специалистов даем права персонала
    #         if emp.position and "hr" in emp.position.title.lower():
    #             user.is_staff = True
    #             user.save()
    #
    #         users.append(user)
    #     return users

    def create_salaries(self, employees):
        current_year = datetime.now().year
        current_month = datetime.now().month

        for emp in employees:
            if emp.status != "employee":
                continue

            # Создаем зарплаты за последние 12 месяцев
            for month_offset in range(0, 13):
                month = current_month - month_offset
                year = current_year

                if month < 1:
                    month += 12
                    year -= 1

                base_salary = emp.position.base_salary if emp.position else Decimal('80000.00')
                bonus = base_salary * Decimal(random.uniform(0.05, 0.2))
                allowances = base_salary * Decimal(random.uniform(0.02, 0.1))

                Salary.objects.create(
                    employee=emp,
                    year=year,
                    month=month,
                    base_salary=base_salary,
                    bonus=bonus,
                    allowances=allowances
                )

    def create_work_shifts(self, employees):
        today = timezone.now().date()

        # Прошлый месяц
        for emp in employees:
            if emp.status != "employee":
                continue

            for day in range(1, 29):  # Примерно 4 недели
                date = today.replace(day=1) - timedelta(days=day)
                if date.weekday() >= 5:  # Пропускаем выходные
                    continue

                WorkShift.objects.create(
                    employee=emp,
                    date=date,
                    start_time="09:00:00",
                    end_time="18:00:00",
                    shift_type="day"
                )

        # Следующий месяц
        for emp in employees:
            if emp.status != "employee":
                continue

            for day in range(1, 31):
                date = today.replace(day=28) + timedelta(days=day)
                if date.weekday() >= 5:  # Пропускаем выходные
                    continue

                # Случайное изменение графика для некоторых сотрудников
                if random.choice([True, False]):
                    WorkShift.objects.create(
                        employee=emp,
                        date=date,
                        start_time="09:00:00",
                        end_time="18:00:00",
                        shift_type="day"
                    )
                else:
                    # Вечерняя или ночная смена
                    shift_type = "evening"
                    start_hour = 14

                    WorkShift.objects.create(
                        employee=emp,
                        date=date,
                        start_time=f"{start_hour}:00:00",
                        end_time=f"{start_hour + 8}:00:00",
                        shift_type=shift_type
                    )

    def create_work_history(self, employees, departments, positions):
        for emp in employees[:15]:  # Только для 15 сотрудников
            change_date = emp.hire_date + timedelta(days=random.randint(180, 1000))
            change_type = random.choice(["transfer", "promotion"])

            prev_dept = random.choice(departments)
            new_dept = random.choice([d for d in departments if d != prev_dept])

            prev_pos = random.choice(positions)
            new_pos = random.choice([p for p in positions if p != prev_pos])

            WorkHistory.objects.create(
                employee=emp,
                change_date=change_date,
                change_type=change_type,
                previous_department=prev_dept,
                new_department=new_dept,
                previous_position=prev_pos,
                new_position=new_pos
            )

    def create_interviews(self, employees, users):
        # Берем только кандидатов (последние 10 в списке)
        candidates = employees[-10:]
        hr_users = [user for user in users if user.is_staff]

        if not hr_users:
            return

        for candidate in candidates:
            if candidate.status in ["new", "review"]:
                interview_date = timezone.now() + timedelta(days=random.randint(1, 14))

                Interview.objects.create(
                    employee=candidate,
                    hr=random.choice(hr_users),
                    datetime=interview_date,
                    platform=random.choice(["zoom", "google_meet"]),
                    link=f"https://meet.google.com/{''.join(random.choices('abcdefghijklmnopqrstuvwxyz1234567890', k=12))}",
                    interview_type=random.choice(["phone", "tech", "hr"]),
                    is_available=False,
                    duration=random.choice([30, 45, 60])
                )

    def create_notifications(self, users):
        notifications = [
            {"type": "salary", "content": "Вам начислена зарплата за последний месяц"},
            {"type": "interview", "content": "Запланировано новое собеседование"},
            {"type": "new_application", "content": "Новый отклик на вакансию"}
        ]

        for user in users:
            for _ in range(random.randint(1, 3)):
                note = random.choice(notifications)
                Notification.objects.create(
                    user=user,
                    notification_type=note["type"],
                    content=note["content"]
                )