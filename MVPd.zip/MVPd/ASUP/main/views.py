from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from ASUP.utils.decorators import *



def index (request):
    return render (request, 'main/index/index.html')


