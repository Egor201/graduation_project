from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db.models import Sum, Max
from decimal import Decimal
from model_utils import FieldTracker
from django.core.exceptions import ValidationError


#Должность
class Position(models.Model):
    title = models.CharField("Название должности", max_length=255)
    description = models.TextField("Описание", blank=True)
    base_salary = models.DecimalField(
        "Базовый оклад",
        max_digits=10,
        decimal_places=2,
        default=0.00
    )

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "Должность"
        verbose_name_plural = "Должности"

#подразделение
class Department(models.Model):
    name = models.CharField("Название подразделения", max_length=255)
    # ''' manager = models.ForeignKey(
    #     Employee,
    #     on_delete=models.SET_NULL,
    #     null=True,
    #     blank=True,
    #     verbose_name="Руководитель"
    # )'''
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Подразделение"
        verbose_name_plural = "Подразделения"

#сотрудники
class Employee(models.Model):

    STATUS_CHOICES = [
        ('new', 'Новый'),
        ('review', 'На рассмотрении'),
        ('rejected', 'Отклонен'),
        ('hired', 'Принят'),
        ('employee', 'Сотрудник'),
    ]

    tracker = FieldTracker(fields=[
            'position',
            'department',
            'hire_date',
            'status',
            'vacancy',
            'test_file',
            'answer_file',
            'contact_info'])
    full_name = models.CharField("ФИО", max_length=255)
    contact_info = models.JSONField("Контактные данные")  # Требуется PostgreSQL
    position = models.ForeignKey(
        Position,
        on_delete=models.SET_NULL,
        null=True,
        verbose_name="Должность"
    )

    department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        verbose_name="Подразделение"
    )
    hire_date = models.DateField("Дата приема на работу")
    resume = models.FileField("Резюме", upload_to='candidates/resumes/', null=True)
    status = models.CharField("Статус", max_length=20, choices=STATUS_CHOICES, default='new')
    #application_date = models.DateField("Дата подачи заявки", auto_now_add=True)
    vacancy = models.ForeignKey(
        'Vacancy',  # Ссылка на модель, которая будет создана позже
        on_delete=models.SET_NULL,
        null=True,
        verbose_name="Вакансия"
    )
    test_file = models.FileField(
        upload_to='vacancies/tests/',
        null=True,
        blank=True,
        verbose_name="Тестовое задание"
    )

    answer_file = models.FileField(
        upload_to='tests/answers/',
        null=True,
        blank=True,
        verbose_name="Ответ кандидата"
    )
    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = "Сотрудник"
        verbose_name_plural = "Сотрудники"

#вакансии
class Vacancy(models.Model):
    STATUS_CHOICES = [
        ('open', 'Открыта'),
        ('closed', 'Закрыта'),
    ]
    tracker = FieldTracker(fields=[
            'title',
            'description',
            'hr',
            'status',
            'close_date',
            'test_file',
            'hh_external_id'])

    title = models.CharField("Название вакансии", max_length=255)
    description = models.TextField("Описание")
    status = models.CharField("Статус", max_length=20, choices=STATUS_CHOICES, default='open')
    publish_date = models.DateField("Дата публикации", auto_now_add=True)
    close_date = models.DateField("Дата закрытия", null=True, blank=True)
    hh_external_id = models.CharField("ID на hh.ru", max_length=100, blank=True)
    test_file = models.FileField(
        upload_to='vacancies/tests/',
        null=True,
        blank=True,
        verbose_name="Тестовое задание"
    )
    hr = models.ForeignKey(
        'User',
        on_delete=models.SET_NULL,
        null=True,
        verbose_name="Ответственный HR",
        related_name='vacancies'
    )
    department = models.ForeignKey(
        'Department',
        on_delete=models.SET_NULL,
        null=True,
        verbose_name="Подразделение",
        #related_name='vacancies'
    )


    def save(self, *args, **kwargs):
        # Получаем исходное состояние до сохранения
        old_instance = Vacancy.objects.get(pk=self.pk) if self.pk else None

        super().save(*args, **kwargs)  # Сначала сохраняем вакансию

        # Если изменилось тестовое задание
        if old_instance and old_instance.test_file != self.test_file:
            self.update_candidates_test_file()

    def update_candidates_test_file(self):
        #Обновляет тестовые задания у всех кандидатов вакансии
        #from .models import Employee  # Импорт внутри метода чтобы избежать циклического импорта

        Employee.objects.filter(vacancy=self).update(
            test_file=self.test_file
        )

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "Вакансия"
        verbose_name_plural = "Вакансии"

#Зарплаты
class Salary(models.Model):
    tracker = FieldTracker(fields=[
        'year',
        'month',
        'base_salary',
        'bonus',
        'allowances',
        'tax',
        'insurance',
        'total_salary'])
    employee = models.ForeignKey(
        'Employee',
        on_delete=models.CASCADE,
        verbose_name="Сотрудник"
    )
    year = models.PositiveIntegerField("Год", default=2025)
    month = models.PositiveIntegerField(
        "Месяц",
        choices=[
            (1, 'Январь'), (2, 'Февраль'), (3, 'Март'),
            (4, 'Апрель'), (5, 'Май'), (6, 'Июнь'),
            (7, 'Июль'), (8, 'Август'), (9, 'Сентябрь'),
            (10, 'Октябрь'), (11, 'Ноябрь'), (12, 'Декабрь')
        ],
        default=1
    )
    base_salary = models.DecimalField(
        "Оклад",
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00')
    )
    bonus = models.DecimalField(
        "Премия",
        max_digits=12,
        decimal_places=2,
        default=0.00
    )
    allowances = models.DecimalField(
        "Надбавки",
        max_digits=12,
        decimal_places=2,
        default=0.00
    )
    tax = models.DecimalField(
        "НДФЛ",
        max_digits=12,
        decimal_places=2,
        default=0.00
    )
    insurance = models.DecimalField(
        "Страховые взносы",
        max_digits=12,
        decimal_places=2,
        default=0.00
    )
    is_tax_auto = models.BooleanField(
        "НДФЛ рассчитан автоматически",
        default=True
    )
    is_insurance_auto = models.BooleanField(
        "Взносы рассчитаны автоматически",
        default=True
    )
    calculation_date = models.DateField(
        "Дата расчета",
        auto_now_add=True
    )
    total_salary = models.DecimalField(
        "Итоговая сумма",
        max_digits=12,
        decimal_places=2,
        editable=False
    )
    INSURANCE_RATE_CHOICES = [
        (0.30, 'Стандартный (30%)'),
        (0.15, 'Пониженный (15%)'),
        (0.07, 'Льготный (7%)'),
    ]
    insurance_rate = models.FloatField(
        "Ставка страховых взносов",
        choices=INSURANCE_RATE_CHOICES,
        default=0.30
    )
    # record_exists = models.BooleanField(
    #     "Флаг обновления записи",
    #     default=False
    # )

    def clean(self):
        """Валидация данных перед сохранением"""
        if self.month < 1 or self.month > 12:
            raise ValidationError("Некорректный месяц")

        if self.year < 2000 or self.year > 2100:
            raise ValidationError("Некорректный год")

    @classmethod
    def get_monthly_summary(cls):
        # Основной запрос для агрегированных данных
        summary = cls.objects.values('year', 'month').annotate(
            total_base=Sum('base_salary'),
            total_bonus=Sum('bonus'),
            total_allowances=Sum('allowances'),
            total_tax=Sum('tax'),
            total_insurance=Sum('insurance'),
            total_salary=Sum('total_salary'),
            calculation_date=Max('calculation_date')
        ).order_by('-year', '-month')

        # Добавляем детализацию для каждой записи
        for entry in summary:
            entry['details'] = Salary.objects.filter(
                year=entry['year'],
                month=entry['month']
            ).select_related('employee')

        return summary
    def calculate_ndfl(self):
        """Расчет НДФЛ с использованием Decimal"""
        income = self.base_salary + self.bonus + self.allowances
        brackets = [
            (Decimal('2400000'), Decimal('0.13')),
            (Decimal('5000000'), Decimal('0.15')),
            (Decimal('20000000'), Decimal('0.18')),
            (Decimal('50000000'), Decimal('0.20')),
            (Decimal('Infinity'), Decimal('0.22'))
        ]
        print(self.year)
        tax = Decimal('0')
        prev_limit = Decimal('0')
        cumulative = Salary.objects.filter(
            employee=self.employee,
            year=self.year
        ).aggregate(total=Sum('total_salary') + Sum('tax')
                    )['total'] or Decimal('0')

        cumulative -= Salary.objects.filter(
            id=self.id
        ).aggregate(total=Sum('total_salary') + Sum('tax')
                    )['total'] or Decimal('0')

        print(cumulative)
        #cumulative = self.cumulative_income + income
        #print(cumulative)
        cumulative += income


        for limit, rate in brackets:
            if cumulative <= prev_limit:
                break

            bracket_size = limit - prev_limit
            taxable = min(cumulative - prev_limit, bracket_size)

            if taxable > 0:
                tax += taxable * rate

            prev_limit = limit
        cumulative_ndfl = Salary.objects.filter(
            employee=self.employee,
            year=self.year
        ).aggregate(total=Sum('tax')
                    )['total'] or Decimal('0')

        cumulative_ndfl -= Salary.objects.filter(
            id=self.id
        ).aggregate(total=Sum('tax')
                    )['total'] or Decimal('0')
        tax -= cumulative_ndfl
        return tax.quantize(Decimal('0.01'))

    def calculate_insurance(self):
        """Расчет страховых взносов с Decimal"""
        if not (self.is_insurance_auto):
            return Decimal('0')

        rate = Decimal(str(self.insurance_rate))
        return (self.base_salary + self.bonus + self.allowances) * rate

    def save(self, *args, **kwargs):
        # Расчет накопленного дохода для новых записей
        # prev_total = Decimal(0)
        # if not self.pk:
        #     prev_total = Salary.objects.filter(
        #         employee=self.employee,
        #         year=self.year
        #     ).aggregate(total=Sum('base_salary') + Sum('bonus') + Sum('allowances')
        #     )['total'] or Decimal('0')



        # if not self.tax.compare(Decimal('0')):
        #     self.cumulative_income -= (self.base_salary + self.bonus + self.allowances)
        #     #self.cumulative_ndfl -= self.tax
        #     self.cumulative_income -= self.tax
        #     #self.cumulative_insurance -= self.insurance



        # Автоматический расчет налогов
        if self.is_tax_auto:
            self.tax = self.calculate_ndfl()
            #self.cumulative_ndfl += self.tax

        if self.is_insurance_auto:
            self.insurance = self.calculate_insurance()
            #self.cumulative_insurance += self.insurance

        # self.cumulative_income = (
        #         prev_total +
        #         self.base_salary +
        #         self.bonus +
        #         self.allowances +
        #         self.tax
        # )

        # Итоговый расчет (все операции с Decimal)
        self.total_salary = (
                self.base_salary +
                self.bonus +
                self.allowances -
                self.tax
                #self.insurance
        )

        super().save(*args, **kwargs)

    def year_month(self):
        return f"{self.year}-{self.get_month_display()}"  # Формат: "2024-01"

    class Meta:
        verbose_name = "Зарплата"
        verbose_name_plural = "Зарплаты"
        unique_together = ('employee', 'year', 'month')
        ordering = ['-year', '-month']
        indexes = [
            models.Index(fields=['employee', 'year']),
        ]

    def __str__(self):
        return f"{self.employee} - {self.get_month_display()} {self.year}"

#История работы
class WorkHistory(models.Model):
    CHANGE_TYPE_CHOICES = [
        ('transfer', 'Перевод'),
        ('promotion', 'Повышение'),
        ('dismissal', 'Увольнение'),
    ]

    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        verbose_name="Сотрудник"
    )
    change_date = models.DateField("Дата изменения")
    change_type = models.CharField("Тип изменения", max_length=20, choices=CHANGE_TYPE_CHOICES)
    previous_department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        related_name='previous_department',
        verbose_name="Предыдущее подразделение"
    )
    new_department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        related_name='new_department',
        verbose_name="Новое подразделение"
    )
    previous_position = models.ForeignKey(
        Position,
        on_delete=models.SET_NULL,
        null=True,
        related_name='previous_position',
        verbose_name="Предыдущая должность"
    )
    new_position = models.ForeignKey(
        Position,
        on_delete=models.SET_NULL,
        null=True,
        related_name='new_position',
        verbose_name="Новая должность"
    )

    def __str__(self):
        return f"{self.change_type} - {self.employee}"

    class Meta:
        verbose_name = "История изменений"
        verbose_name_plural = "История изменений"
#Пользователи для Telegram
class User(AbstractUser):
    #telegram_id = models.CharField("Telegram ID", max_length=100, unique=True, null=True, default=None)
    # role = models.CharField("Роль", max_length=20, choices=ROLES, default='employee')
    telegram_id = models.BigIntegerField(null=True, blank=True, unique=True)
    telegram_bind_code = models.CharField(max_length=6, null=True, blank=True)
    employee = models.OneToOneField(
        Employee,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        db_index=True,
        verbose_name="Связанный сотрудник"
    )
    # Убираем стандартные поля username
    # username = None
    # USERNAME_FIELD = 'telegram_id'
    # REQUIRED_FIELDS = []

    # objects = CustomUserManager()
    #
    # Исправленные поля groups и user_permissions
    # groups = models.ManyToManyField(
    #     'auth.Group',
    #     related_name='custom_user_groups',
    #     blank=True,
    #     verbose_name='Группы',
    # )
    # user_permissions = models.ManyToManyField(
    #     'auth.Permission',
    #     related_name='custom_user_permissions',
    #     blank=True,
    #     verbose_name='Права',
    # )
    #
    # def __str__(self):
    #     return f"{self.telegram_id} ({self.role})"

    # class Meta:
    #     verbose_name = "Пользователь"
    #     verbose_name_plural = "Пользователи"
#Уведомления
class Notification(models.Model):
    NOTIFICATION_TYPES = [
        ('new_application', 'Новый отклик'),
        ('salary', 'Начисление зарплаты'),
        ('interview', 'Собеседование'),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        verbose_name="Пользователь"
    )
    notification_type = models.CharField("Тип уведомления", max_length=20, choices=NOTIFICATION_TYPES)
    content = models.TextField("Содержание")
    sent_date = models.DateTimeField("Дата отправки", auto_now_add=True)
    is_read = models.BooleanField("Прочитано", default=False)

    def __str__(self):
        return f"{self.user}: {self.notification_type}"

    def send_telegram_notification(self):
        if self.user.telegram_id:
            from services.telegram import send_message
            send_message(self.user.telegram_id, self.content)

    # def send_telegram_notification(self):
    #     if self.user.telegram_id:
    #         message = f"🔔 <b>{self.get_notification_type_display()}</b>\n————————————\n{self.content}"
    #         from services.telegram import send_telegram_message
    #         return send_telegram_message(self.user.telegram_id, message)
    #     return False


    class Meta:
        verbose_name = "Уведомление"
        verbose_name_plural = "Уведомления"
#Собеседования
class Interview(models.Model):
    PLATFORM_CHOICES = [
        ('zoom', 'Zoom'),
        ('google_meet', 'Google Meet'),
        ('other', 'Другое'),
    ]
    INTERVIEW_TYPES = [
        ('phone', 'Телефонное'),
        ('tech', 'Теническое'),
        ('hr', 'С HR'),
        ('final', 'Финальное'),
    ]
    tracker = FieldTracker(fields=['hr','datetime','platform','link'])
    employee = models.ForeignKey(
        Employee,
        null=True,
        on_delete=models.CASCADE,
        verbose_name="Кандидат",
        related_name = "candidate"

    )
    booked_at = models.DateTimeField(
        "Время записи",
        null=True,
        blank=True
    )
    hr = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        verbose_name="HR-специалист",
        related_name = "hr"
    )
    datetime = models.DateTimeField("Дата и время")
    platform = models.CharField("Платформа", max_length=20, choices=PLATFORM_CHOICES)
    link = models.URLField("Ссылка", max_length=500)

    # application = models.ForeignKey(
    #     Application,
    #     on_delete=models.CASCADE,
    #     null=True,
    #     blank=True,
    #     verbose_name="Отклик на вакансию"
    # )
    interview_type = models.CharField(
        "Тип собеседования",
        max_length=20,
        choices=INTERVIEW_TYPES,
        default='phone'
    )
    is_available = models.BooleanField(
        "Свободный слот",
        default=True,
        help_text="Отметьте для открытых слотов самозаписи"
    )
    duration = models.PositiveIntegerField(
        "Длительность (мин)",
        default=60
    )
    notes = models.TextField(
        "Заметки",
        blank=True,
        help_text="Внутренние заметки HR"
    )

    def __str__(self):
        return f"{self.get_interview_type_display()} - {self.employee} ({self.datetime})"

    class Meta:
        verbose_name = "Слот собеседования"
        verbose_name_plural = "Слоты собеседований"
        ordering = ['-datetime']
#график работы
class WorkShift(models.Model):
    SHIFT_TYPES = [
        ('day', 'Дневная'),
        ('evening', 'Вечерняя'),
        ('night', 'Ночная'),
        ('other', 'Другая')
    ]
    tracker = FieldTracker(fields=['date','start_time','end_time','shift_type','comment'])

    employee = models.ForeignKey(
        'Employee',
        on_delete=models.CASCADE,
        related_name='shifts',
    )
    date = models.DateField(verbose_name="Дата смены")
    start_time = models.TimeField(verbose_name="Начало")
    end_time = models.TimeField(verbose_name="Окончание")
    shift_type = models.CharField(
        max_length=20,
        choices=SHIFT_TYPES,
        default='day',
        verbose_name="Тип смены"
    )
    comment = models.TextField(
        blank=True,
        verbose_name="Комментарий"
    )

    class Meta:
        ordering = ['date', 'start_time']
        unique_together = ['employee', 'date']
        verbose_name = "Рабочая смена"
        verbose_name_plural = "Рабочие смены"

    def __str__(self):
        return f"{self.date} {self.get_shift_type_display()} ({self.employee})"

    def clean(self):
        # Проверка, что начало смены раньше окончания
        if self.start_time >= self.end_time:
            raise ValidationError("Время окончания смены должно быть позже начала")
