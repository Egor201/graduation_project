from django.contrib import admin
from .models import *

class CustomAdminSite(admin.AdminSite):
    def has_permission(self, request):
        return request.user.is_active and (request.user.role == 'admin')



class WorkShiftAdmin(admin.ModelAdmin):
    list_display = ('date', 'employee', 'shift_type', 'start_time', 'end_time')
    list_filter = ('date', 'shift_type', 'employee')
    search_fields = ('employee__first_name', 'employee__last_name')
    date_hierarchy = 'date'

    fieldsets = (
        (None, {
            'fields': ('employee', 'date', 'shift_type')
        }),
        ('Время', {
            'fields': ('start_time', 'end_time')
        }),
        ('Дополнительно', {
            'fields': ('comment',),
            'classes': ('collapse',)
        }),
    )


class SalaryAdmin(admin.ModelAdmin):
    readonly_fields = ('cumulative_income', 'total_salary')

admin_site = CustomAdminSite(name='custom_admin')

admin_site.register(Employee)  # Только для админов

# Регистрация всех моделей
admin.site.register(Position)
admin.site.register(Department)
admin.site.register(Employee)
admin.site.register(Vacancy)
admin.site.register(Salary)
admin.site.register(WorkHistory)
admin.site.register(User)
admin.site.register(Notification)
admin.site.register(Interview)
admin.site.register(WorkShift)

admin.site.site_header = "АСУП - Администрирование"
admin.site.site_title = "Панель управления АСУП"
admin.site.index_title = "Добро пожаловать в систему управления персоналом"