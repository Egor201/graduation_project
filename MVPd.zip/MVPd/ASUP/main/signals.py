from django.db.models.signals import post_save, pre_save, pre_delete
from django.dispatch import receiver
from django.utils import timezone
from datetime import timedelta
from .models import (
    Notification, User, Employee,
    Vacancy, Interview,
    Salary, WorkShift,
#Application
)


# ========================
# Уведомления для HR
# ========================

@receiver(post_save, sender=Employee)
def notify_hr_new_candidate(sender, instance, created, **kwargs):
    """Уведомление о новом кандидате"""
    if created and instance.vacancy and instance.vacancy.hr:
        Notification.objects.create(
            user=instance.vacancy.hr,
            notification_type='new_application',
            content=f"Новый кандидат: {instance.full_name} ({instance.vacancy.title})"
        )


@receiver(post_save, sender=Employee)
def notify_hr_file_upload(sender, instance, **kwargs):
    """Уведомление о загрузке файлов кандидатом"""
    changed_fields = instance.tracker.changed()
    file_fields = ['resume', 'answer_file']

    if any(field in changed_fields for field in file_fields) and instance.vacancy.hr:
        Notification.objects.create(
            user=instance.vacancy.hr,
            notification_type='file_uploaded',
            content=f"Кандидат {instance.full_name} обновил файлы: {', '.join(changed_fields)}"
        )


@receiver(pre_save, sender=Vacancy)
def notify_vacancy_changes(sender, instance, **kwargs):
    """Уведомление об изменениях в вакансии"""
    if not instance.pk:
        return

    old = Vacancy.objects.get(pk=instance.pk)
    changes = []

    tracker = instance.tracker
    if tracker.has_changed('status'):
        changes.append(f"Статус: {instance.get_status_display()}")
    if tracker.has_changed('test_file'):
        changes.append("Тестовое задание обновлено")
    if tracker.has_changed('description'):
        changes.append("Описание вакансии изменено")

    if changes and instance.hr:
        Notification.objects.create(
            user=instance.hr,
            notification_type='vacancy_update',
            content=f"Вакансия '{instance.title}': {', '.join(changes)}"
        )


# ========================
# Уведомления для кандидатов/сотрудников
# ========================

# @receiver(post_save, sender=Application)
# def notify_application_status(sender, instance, **kwargs):
#     """Уведомление об изменении статуса отклика"""
#     if instance.tracker.has_changed('status'):
#         # Для кандидата
#         Notification.objects.create(
#             user=instance.employee.user,
#             notification_type='application_status',
#             content=f"Статус вашего отклика: {instance.get_status_display()}"
#         )
#
#         # Для HR
#         if instance.vacancy.hr:
#             Notification.objects.create(
#                 user=instance.vacancy.hr,
#                 notification_type='hr_application_status',
#                 content=f"Отклик {instance.employee.full_name}: {instance.get_status_display()}"
#             )


@receiver(post_save, sender=Interview)
def notify_interview_changes(sender, instance, **kwargs):
    """Уведомление об изменениях в собеседовании"""
    changed_fields = instance.tracker.changed()
    if changed_fields and instance.employee:
        changes = ", ".join([f"{field} изменен" for field in changed_fields])
        message = (
            f"🗓 Собеседование обновлено!\n"
            f"Изменения: {changes}\n"
            f"Новое время: {instance.datetime.astimezone().strftime('%d.%m.%Y %H:%M')}"
        )
        Notification.objects.create(
            user=instance.employee.user,
            notification_type='interview_update',
            content=message
        )
    if changed_fields and instance.hr:
        changes = ", ".join([f"{field} изменен" for field in changed_fields])
        message = (
            f"🗓 Собеседование обновлено!\n"
            f"Изменения: {changes}\n"
            f"Новое время: {instance.datetime.astimezone().strftime('%d.%m.%Y %H:%M')}"
        )
        Notification.objects.create(
            user=instance.hr,
            notification_type='interview_update',
            content=message
        )


@receiver(post_save, sender=WorkShift)
def notify_shift_changes(sender, instance, **kwargs):
    """Уведомление об изменении графика смен"""
    if instance.tracker.changed():
        changes = ", ".join([
            f"{field}: {getattr(instance, field)}"
            for field in instance.tracker.changed()
        ])
        Notification.objects.create(
            user=instance.employee.user,
            notification_type='shift_change',
            content=f"Изменена смена {instance.date}:\n{changes}"
        )


# ========================
# Уведомления о зарплате
# ========================

@receiver(post_save, sender=Salary)
def notify_salary_calculation(sender, instance, created, **kwargs):
    """Уведомление о расчете зарплаты"""
    if instance.tracker.has_changed('total_salary') or created:
        Notification.objects.create(
            user=instance.employee.user,
            notification_type='salary',
            content=(
                f"Начислена зарплата за {instance.year}-{instance.month:02d}\n"
                f"Итого: {instance.total_salary} ₽\n"
                f"НДФЛ: {instance.tax} ₽"
            )
        )


# ========================
# Системные уведомления
# ========================

@receiver(pre_delete, sender=Vacancy)
def notify_vacancy_deletion(sender, instance, **kwargs):
    """Уведомление об удалении вакансии"""
    if instance.hr:
        Notification.objects.create(
            user=instance.hr,
            notification_type='system',
            content=f"Вакансия '{instance.title}' удалена!"
        )


# ========================
# Напоминания
# ========================

# @receiver(post_save, sender=Interview)
# def schedule_reminders(sender, instance, **kwargs):
#     """Планирование напоминаний о собеседовании"""
#     from .tasks import send_reminder  # Реализовать в tasks.py
#
#     # Напоминание за 1 день
#     reminder_day = instance.datetime - timedelta(days=1)
#     if reminder_day > timezone.now():
#         send_reminder.apply_async(
#             args=[instance.id, 'day'],
#             eta=reminder_day
#         )
#
#     # Напоминание за 1 час
#     reminder_hour = instance.datetime - timedelta(hours=1)
#     if reminder_hour > timezone.now():
#         send_reminder.apply_async(
#             args=[instance.id, 'hour'],
#             eta=reminder_hour
#         )


# ========================
# Интеграции
# ========================

# @receiver(post_save, sender=Employee)
# def sync_employee_changes(sender, instance, **kwargs):
#     """Синхронизация изменений сотрудника с внешними системами"""
#     if instance.tracker.changed():
#         changed_fields = ", ".join(instance.tracker.changed())
#         from .integrations import update_hr_system  # Реализовать интеграцию
#         update_hr_system(instance)
#
#         Notification.objects.create(
#             user=instance.user,
#             notification_type='integration',
#             content=f"Данные синхронизированы. Измененные поля: {changed_fields}"
#         )


@receiver(post_save, sender=Notification)
def handle_notification_delivery(sender, instance, created, **kwargs):
    """Отправка уведомления через Telegram"""
    if created:
        instance.send_telegram_notification()